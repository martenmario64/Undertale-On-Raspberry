#!/bin/bash

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DATA_FOLDER="$SCRIPT_DIR"
#Install Script For Undertale - Pi Edition

if [ "$1" != "--in-terminal" ]; then
    lxterminal -e "bash -c '$0 --in-terminal; exec bash'"
    exit
fi

echo Installing Undertale - Pi Edition...
echo This Project Would Have Not Been Possible
echo Without The Great People At Pi-Apps!
echo Support Botspot!

DIRECTORY="$HOME/.martenapps/"

if [ -d "$DIRECTORY" ]; then
	echo "Packages Installed, Moving On."
else
	sudo apt remove box64 -y
	wget -qO- https://raw.githubusercontent.com/Botspot/pi-apps/master/install | bash
	~/pi-apps/manage install Box86
	~/pi-apps/manage install Box64
	~/pi-apps/manage install "Wine (x86)"
	~/pi-apps/manage install "Wine (x64)"

	sudo apt install xdelta3 -y
fi

echo "NOTE: You Will Need A Vaild Copy Of Undertale (Any Version Supported.)"

rm -r ~/.martenapps/Undertale-Pi/
mkdir ~/.martenapps/
mkdir ~/.martenapps/Undertale-Pi/
cp -r $DATA_FOLDER/Game/ ~/.martenapps/Undertale-Pi/
cp $DATA_FOLDER/.files/runner.sh ~/.martenapps/Undertale-Pi/Game/runner.sh
rm ~/.martenapps/Undertale-Pi/Game/PUT\ STEAM\ GAME\ HERE.txt
cp $DATA_FOLDER/.files/runner.sh ~/Desktop/Undertale.sh

echo "Finished! Go To The Desktop And Find "Undertale.sh"!"
echo "Press Any Button To Close."
read button